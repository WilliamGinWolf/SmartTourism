package database;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class DBUtil {
	// table
	public static final String TABLE_PASSWORD = "table_user_password";
	public static final String TABLE_USERINFO = "table_user_info";

	// connect to MySql database
	public static Connection getConnect() {
		String url = "jdbc:mysql://localhost:3306/test"; // 数据库的Url
		Connection connecter = null;
		try {
			Class.forName("com.mysql.jdbc.Driver"); // java反射，固定写法
			connecter = (Connection) DriverManager
					.getConnection(url + "?useUnicode=true&characterEncoding=utf-8&useSSL=false", "root", "158815");
		} catch (ClassNotFoundException e) {
			System.out.println("11111111111111111111111");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("2222222222222222");
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
			System.out.println("VendorError: " + e.getErrorCode());
		}
		return connecter;
	}

}